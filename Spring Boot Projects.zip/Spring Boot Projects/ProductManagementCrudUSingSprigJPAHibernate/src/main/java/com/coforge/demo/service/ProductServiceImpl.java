package com.coforge.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coforge.demo.model.Product;
import com.coforge.demo.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepository repo;

	@Override
	public String addProduct(Product product) {

		return repo.addProduct(product);
	}

	@Override
	public Product updateProduct(Product product) {

		return repo.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {

		return repo.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {

		return repo.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return repo.getAllProducts();
	}

	@Override
	public List<Product> getProductsByName(String pname) {

		return repo.getProductsByName(pname);
	}

	@Override
	public List<Product> getProductsInBetween(int iPrice, int price) {

		return repo.getProductsInBetween(iPrice, price);
	}

}
