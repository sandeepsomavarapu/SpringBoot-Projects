package com.coforge.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.coforge.demo.model.Product;

@Repository
public class ProductRepositoryImpl implements ProductRepository {
	@PersistenceContext
	EntityManager entityManager;// persist,remove,merge,find,createQuery

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		return "Product Saved .....";
	}

	@Override
	public Product updateProduct(Product product) {

		return entityManager.merge(product);
	}

	@Override
	public String deleteProduct(int productId) {
		entityManager.remove(getProduct(productId));
		return "Product Removed....";
	}

	@Override
	public Product getProduct(int productId) {

		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p", Product.class);

		return products.getResultList();

	}

	@Override
	public List<Product> getProductsByName(String pname) {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p where p.productName=?1" ,
				Product.class);
		products.setParameter(1,pname);

		return products.getResultList();

	}

	@Override
	public List<Product> getProductsInBetween(int iPrice, int price) {
		TypedQuery<Product> products = entityManager
				.createQuery("select p from Product p where p.productPrice between ?1 and ?2", Product.class);
		products.setParameter(1, iPrice);
		products.setParameter(2, price);
		return products.getResultList();
	}

}
