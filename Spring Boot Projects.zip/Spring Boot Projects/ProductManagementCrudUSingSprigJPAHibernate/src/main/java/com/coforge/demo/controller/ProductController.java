package com.coforge.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.coforge.demo.model.Product;
import com.coforge.demo.service.ProductService;

@RestController // @Controller+@ResponseBody @RequestMapping

@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService service;

	@PostMapping("/insertProduct") // http://localhost:8586/product/insertProduct
	public String addProduct(@RequestBody Product product) {
		return service.addProduct(product);

	}

	@PutMapping("/updateProduct") // http://localhost:8586/product/updateProduct
	public Product updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);

	}

	@DeleteMapping("/deleteProduct/{pid}") // http://localhost:8586/product/deleteProduct/123
	public String deleteProduct(@PathVariable("pid") int productId) {
		return service.deleteProduct(productId);

	}

	@GetMapping("/getProduct/{id1}") // http://localhost:8586/product/getProduct/123
	public Product getProduct(@PathVariable("id1") int productId) {
		return service.getProduct(productId);

	}

	@GetMapping("/getAllProducts") // http://localhost:8586/product/getAllProducts
	public List<Product> getAllProduct() {
		return service.getAllProducts();
	}

	@GetMapping("/getAllProductsByName/{name}") // http://localhost:8586/product//getAllProductsByName/mobile
	public List<Product> getAllProductsByName(@PathVariable("name") String name) {
		return service.getProductsByName(name);
	}

	@GetMapping("/getAllProductsByPrice/{iprice}/{price}") // http://localhost:8586/product/getAllProductsByPrice/2000/3000
	public List<Product> getAllProductsByPriceRange(@PathVariable("iprice") int iPrice,
			@PathVariable("price") int price) {
		return service.getProductsInBetween(iPrice, price);
	}
}
