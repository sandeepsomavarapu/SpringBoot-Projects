package com.coforge.demo.repository;

import java.util.List;

import com.coforge.demo.model.Product;

public interface ProductRepository {
	public String addProduct(Product product);

	public Product updateProduct(Product product);

	public String deleteProduct(int productId);

	public Product getProduct(int productId);

	public List<Product> getAllProducts();

	public List<Product> getProductsByName(String pname);

	public List<Product> getProductsInBetween(int iPrice, int price);
}
