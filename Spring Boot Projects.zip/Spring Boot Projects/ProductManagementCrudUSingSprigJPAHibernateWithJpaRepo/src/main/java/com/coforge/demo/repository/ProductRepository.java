package com.coforge.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.coforge.demo.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {
	//@Query(select e from Product e where e.productName=?1)
	public List<Product> findByProductName(String productName);
	
	public List<Product> findByProductPriceBetween(int iPrice,int price);
	
}
